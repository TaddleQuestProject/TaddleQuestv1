class PagesController < ApplicationController
  def index
  end

  def page1
    
  end


  def page2
  end

  def page3
  
  end

  def page4
    @weapons = Weapon.all

  end
  def page44
    @weapons = Weapon.all

  end
  def victory
    
  end
  def defeat
    
  end
  def inventory
  end

  def status
  	
  end
end
