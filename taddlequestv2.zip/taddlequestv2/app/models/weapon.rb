class Weapon < ApplicationRecord
end
