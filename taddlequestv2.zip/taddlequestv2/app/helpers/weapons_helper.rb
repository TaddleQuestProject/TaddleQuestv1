module WeaponsHelper
end
